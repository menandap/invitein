
<?php $__env->startSection('title', 'Transaction'); ?>
<?php $__env->startSection('page1', 'Transaction'); ?>
<?php $__env->startSection('page2', 'Transaction List'); ?>            

<?php $__env->startSection('content'); ?>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success alert-dismissible text-white" role="alert">
            <span class="text-sm"><?php echo e($message); ?></span>
            <button type="button" class="btn-close text-lg py-3 opacity-10" data-bs-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if($message = Session::get('error')): ?>
        <div class="alert alert-danger alert-dismissible text-white" role="alert">
            <span class="text-sm"><?php echo e($message); ?></span>
            <button type="button" class="btn-close text-lg py-3 opacity-10" data-bs-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>            
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <div class="table">
                            <div class="row">
                                <div class="col-6 align-items-center">
                                    <h2 class="mb-0">Transaction List</h2>
                                </div>
                                <div class="col-6 text-end align-items-center">
                                    <a class="btn bg-gradient-success mb-0" href="/admin/couriers/create"><i class="material-icons text-sm">add</i>&nbsp;&nbsp;Add Transaction</a>
                                </div>
                            </div>
                            <br>                    
                            <div class="table-responsive">
                                <table class="table align-items-center mb-0">
                                    <thead>
                                        <tr>
                                            <th class="text-uppercase text-secondary text-lg font-weight-bolder ps-2">No.</th>
                                            <th class="text-uppercase text-secondary text-lg font-weight-bolder ps-2">Undangan</th>
                                            <th class="text-uppercase text-secondary text-lg font-weight-bolder ps-2">Mulai</th>
                                            <th class="text-uppercase text-secondary text-lg font-weight-bolder ps-2">Berakhir</th>
                                            <th class="text-uppercase text-secondary text-lg font-weight-bolder ps-2">Keyword</th>
                                            <th colspan="2" class="text-uppercase text-secondary text-lg font-weight-bolder ps-2">Action</th>            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><p class="text-md font-weight-normal mb-0"><?php echo e($transactions->firstItem()+$loop->index); ?></p></th>
                                            <td><p class="text-md font-weight-normal mb-0"><?php echo e($transaction->id_undangan); ?></p></td>                
                                            <td><p class="text-md font-weight-normal mb-0"><?php echo e($transaction->keyword); ?></p></td>
                                            <td><p class="text-md font-weight-normal mb-0"><?php echo e($transaction->date_start); ?></p></td>
                                            <td><p class="text-md font-weight-normal mb-0"><?php echo e($transaction->date_end); ?></p></td>
                                            <td class="align-middle text-center">
                                                <div class="d-flex align-items-center">
                                                    <a href="" class="m-1 btn bg-gradient-info"><i class="material-icons text-sm me-2">visibility</i>View</a>
                                                    <a href="" class="m-1 btn bg-gradient-warning"><i class="material-icons text-sm me-2">edit</i>Edit</a>
                                                    <a href="" class="m-1 btn bg-gradient-danger" onclick="return confirm('Apa yakin ingin menghapus data ini?')"><i class="material-icons text-sm me-2">delete</i>Delete</a>
                                                </div>
                                            </td>                
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>      
                                    </tbody>
                                </table>
                            </div>
                            <?php echo e($transactions->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>                            
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\menandap\invitein\resources\views/dashboard-usr/transactionlist.blade.php ENDPATH**/ ?>